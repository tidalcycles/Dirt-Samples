#!/usr/bin/perl -w

### pattint.pl
### builds array of all intervals between members of a pattern

print "set1\n";
@pattern = (16,17,12,7,10,3,13,8,11,18,14,9);
        foreach $place3 (0..11) {
                $pattern[$place3] = ($pattern[$place3])%12;
                }
foreach $item2 (@pattern) {print "$item2\t";}
print "\n";

foreach $count (0..10) {
	
	$firstplace = $pattern[0];
	foreach $place (0..10) {
		$pattern[$place] = $pattern[($place+1)%12];
		}
	$pattern[11] = $firstplace;

	@newarray = @pattern;
	$thistransp = $newarray[0];

	foreach $place2 (0..11) {
                $newarray[$place2] = ($newarray[$place2]-$thistransp)%12;
                }

	foreach $item (@newarray) {print "$item\t ";}
	print "\n";
	$count = $count + 1;
}
