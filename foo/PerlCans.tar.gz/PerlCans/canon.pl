#!/usr/bin/perl -w
## program canon.pl

@dissonant = (0,1,2,5,6,7,10,11);	#prohibited dyads
@mode = (2,3,6,7,10,11);		#filters pitch inventory

@timepoints = (0,1,2,3,4,5,6,7,8); 
@pitches= (0,7,8,4,11,12,8,15,16);
@timepoints == @pitches || die "timepoints and pitches are not equal";

print ("timepoints: \(@timepoints\)\n");
print ("pitches:    \(@pitches\)\n");

$length = 9;
print("The length is $length\n");

####################################################################
### Create full time-point list @all_points, up to length * length
####################################################################

@all_points = @timepoints;

$counter2 = 1;

until ($counter2 == $length) {
        @multarray = @timepoints;
        foreach $array_item (@multarray) {
                $array_item = $array_item + ($counter2 * $length);
                }
        @all_points = (@all_points, @multarray);
        $counter2 += 1;
}

############ End of creating full tp list all_points ########

################################################################
### Create full pitch list all_pitches, up to length * length
################################################################
@all_pitches = @pitches;

$counter_pit = 1;

until ($counter_pit == $length) {
        @all_pitches = (@all_pitches, @pitches);
        $counter_pit += 1;
}

############ Finished creating all pitches (@all_pitches) ######

### First we create the little master hash (@toparray)

$counter3 = 0;
foreach $step1 ( @timepoints ) {
        $toparray{$step1} =  $pitches[$counter3];
        $counter3 += 1;
        }

### Hash created

### Now we create the full master hash (@bigarray)

$counter4 = 0;
foreach $step2 ( @all_points ) {
        $bigarray{$step2} =  $all_pitches[$counter4];
        $counter4 += 1;
        }

### Full master hash created

print("M  D  T\n");

$printing = 0;

####################Mensuration
$mult = 0;

until ($mult == $length-1) {
	$mult += 1;

%input = (); 

#print("mensuration $mult\n");
#################Transpose
$transp = -1;

until ($transp == 11) {
	$transp += 1;

foreach $place (keys %toparray) {
	$input {$place * $mult} = ($toparray{$place} + $transp); 
	}
#print("The transposition is $transp\n");
#print("The transposed array is: ");
#print "@{[ %input ]}\n";

######################## Test for mode
########################

foreach $mode_element (@mode) { $seen{$mode_element} = 1 }
$in_the_mode = 1;

thisloop: foreach $pit (values %input) {
	unless (exists $seen{$pit % 12})
		{$in_the_mode = 0; last thisloop} 
}

if ($in_the_mode == 1) {	

##################################
################################## Displacement begins
$count = 0;

until ($count == $length -1) {
	$count += 1;

##here I extract the keys as an array and add $count to them
@list = keys(%input);
foreach my $itm (@list) {
$itm = ($itm + $count)
}

%templist = ();

# This writes the displacement hash into templist
foreach $pointer ( @list ) {
	my $newcount = $pointer - $count;
	$templist{$pointer} = $input{$newcount};
	}

%input2 = %templist; # Replace input2 with displacement hash

# Here we test for simultaneities (common keys between input and input2)
my @common = ();
foreach (keys %bigarray) {
	push(@common, $_) if exists $input2{$_};
}
%intarray=();
$dissed = 0;

loop: foreach $attack ( @common ) {
$dissed = 0;
$intarray{$attack} = ($bigarray{$attack}-$input2{$attack})%12;

foreach $note ( @dissonant ) {

if ($intarray{$attack} == $note) 
	{$dissed = 1; last loop} 

	} # End foreach note in @dissonant

} # End foreach $attack in @common

if ($dissed == 0) 
  {print("($mult $count $transp)\n");
#  print "@{[ %intarray ]}\n";
	$printing += 1} 

} #loop of displacements
} #the mode condition

} #transposition level 'until'

} # Mensuration
print ("Found $printing canons.\n");
