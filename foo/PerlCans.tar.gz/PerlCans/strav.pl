#!/usr/bin/perl -w

### strav.pl
### stravinsky-style rotation (twelve-tone only)

@pattern = (4,1,2,9,5,0,10,3,7,6,8,11);

$patt1 = $pattern[0];

## 
        foreach $place3 (0..11) {
                $pattern[$place3] = ($pattern[$place3])%12;
                }
print("\(");
print(join(", ",@pattern));
print "\)\n";

foreach $count (0..10) {
	
	$firstplace = $pattern[0];
	foreach $place (0..10) {
		$pattern[$place] = $pattern[($place+1)%12];
		}
	$pattern[11] = $firstplace;

	@newarray = @pattern;
	$thistransp = $newarray[0];	## starts each rotation at zero
	
	foreach $place2 (0..11) {
                $newarray[$place2] = ($newarray[$place2]-$thistransp+$patt1)%12;
                }
	
	print("\(");
	print(join(", ",@newarray));
	print "\)\n";
	$count = $count + 1;
}
