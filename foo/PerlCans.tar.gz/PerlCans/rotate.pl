#!/usr/bin/perl -w

@pitches = (16,17,12,7,10,3,13,8,11,18,14,9);

$length = $#pitches;

print("pitches are @pitches\n");

$rotation = -1;

until ($rotation == $length) {

$firstpit = $pitches[0];
shift(@pitches);
$pitches[$length] = $firstpit;

foreach $pit (@pitches) {
	print("$pit ");
}

print("\n");
$rotation++;

}
