PerlCans -- canon and sequence manipulation scripts

These are not terribly user-friendly: you have to enter the pitch and
attack-point arrays into the scripts themselves and then run them.

For the perl newbies out there, make sure the first line of each
script is the same as what you get from typing 'which perl' at the
command line. Just say 'chmod +x script.pl' and fire away at the command
line.

Good Luck!
Drew Krause
drkrause@mindspring.com
http://www.wordecho.com/DrewKrause.html

CANON SCRIPTS always produce output as a list of (M D T) where

M = mensuration, or multiple of original tactus
D = displacement, or number of beats later the answer begins
T = transposition, or number of semitones higher in the answer

for each answer that matches successfully against the canon,
according to

"consonance" as defined by your @dissonance array
"mode" as defined by the pitch-class sets you want to include 

canon.pl is for melody against itself

match.pl is for one melody against another

matchsc.pl is for one melody against another, takes only canons
	which have simultaneities

canrot.pl rotates one line against another

pattint.pl takes an intervallic 'snapshot' of all consecutive intervals in a
pattern

matchins.pl
###### matches a fragment of a melody against itself
###### displacements designed for stretto (optional: set
###### max displacements to insidelength)

rotate.pl
prints out rotations of a set

### strav.pl
### stravinsky-style rotation (twelve-tone only)

